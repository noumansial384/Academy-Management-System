//HEADER FILES 
#include <iostream>// For cout, cin (input/output)
#include <fstream>// For file reading/writing (ifstream, ofstream)
#include <string>// For using string data type and string functions
#include <iomanip>// For formatting output (e.g., setw, setprecision)
#include <windows.h>// For adding colors and delays using Windows API

using namespace std;/*allows you to use standard C++ features (like cout, cin, string, etc.)
 without writing std:: every time*/
                                  
HANDLE h=GetStdHandle(STD_OUTPUT_HANDLE);//Console handle for color

const int MAX=100;//Global constants

int rollNumbers[MAX];//Student data

string names[MAX];

int marks[MAX][5]; //English, Math, Science, Language, Computer Science
 
int studentCount=0;

//for Animation and Color Functions 

void setColor(int color)
 {
    SetConsoleTextAttribute(h, color);
}

void typingEffect(string message, int delay=30, int color=7) 
{
	setColor(6);//setColor(6) is used for YELLOW COLOR

    setColor(color);
    for (char ch : message) {
        cout << ch;
        Sleep(delay);
    }
    cout<<endl;
    
    setColor(7); //Reset to white color because 7 is use for white 
}

void loadingAnimation(string text = "Loading . . . . .", int color=6) //setColor(6) is used for YELLOW COLOR
{
    setColor(color);
    
    cout<<text;
    
    for(int i=0;i<5;++i) 
	{
    	
        Sleep(200);
        
        cout << ".";
    }
    cout<<endl;
    
	setColor(7);//setColor(7) is used for white COLOR
}

//Utility Functions
void loadData() 
{
    ifstream file("students.txt");
    
    studentCount =0;
    
    while (file>>rollNumbers[studentCount]) 
	{
        file.ignore();
        
        getline(file, names[studentCount]);
        
		for (int j=0;j<5;j++) 
		{
            file>>marks[studentCount][j];
        }
        studentCount++;
    }
    file.close();
}

void saveData() 
{
    ofstream file("students.txt");
    
    for (int i=0;i<studentCount;i++)
	  {
        file<<rollNumbers[i]<<endl;
        
        file<<names[i]<<endl;
        
		for(int j=0;j<5;j++) 
		{
            file<<marks[i][j]<< " ";
        }
        file<<endl;
    }
    file.close();
}

double calculateAverage(int idx)
 {
    int sum=0;
    for (int i=0;i<5;i++) 
	{
        sum +=marks[idx][i];
    }
    return sum/5.0;
}

//for CALCULATING GRADE 
char calculateGrade(double avg) 
{
    if (avg>=90) return 'A';
    
    else if (avg >= 75) return 'B';
    
	else if (avg >= 50) return 'C';
    
	else return 'F';
}

//Student Panel
void studentMenu(int roll)
 {
    char choice;
    int idx=-1;

    for (int i=0;i<studentCount;i++)
	 {
        if(rollNumbers[i]==roll)
		 {
            idx=i;
            break;
        }
    }

    if (idx==-1) 
	{
        setColor(4);//for RED color
		 
        cout<<"\nStudent NOT Found !\n";
        
        setColor(7);//again WHITE color
		 
        return;
    }

    do {
        system("cls");
        
		setColor(5);//again PURPLE color
		 
        loadingAnimation("Opening Student Dashboard. . .", 10);
        
        setColor(1);//for BLUE color
        
        cout<<endl;
        
		cout<<"#======>   S T U D E N T   <======#\n"<<endl;
        
        setColor(6);//for YELLOW 
        
        cout<<">>> WELCOME !!! , "<<names[idx]<<"!\n"<<endl;
        
        setColor(7);//agin WHITE color
        
        cout<<"------------------------------------\n"<<endl;
        
                setColor(2);//for GREEN  color 

cout<<endl;

        cout<<"1. Check Result\n"<<endl;
        
        cout<<"2. Check Grade\n"<<endl;
        
		cout<<"3. Check Syllabus\n"<<endl;
        
		cout<<"4. Check Attendance\n"<<endl;
        
		cout<<"5. Change Personal Data\n"<<endl;
        
		cout<<"6. Change Login Password\n"<<endl;
		
        setColor(4);//agin RED color
        
		cout<<"7. Exit\n";
		
		cout<<"\n"<<endl;

        setColor(7);//agin WHITE color
        
		cout<<"Enter Your Choice : \n";

        cin>>choice;

        switch (choice) 
		{
            setColor(6);//YELLOW COLOR 
            
		    case '1':
            
			    cout<<"\nMarks:\n";
            
			    cout<<"English: "<<marks[idx][0]<<endl;
            
			    cout<<"Math: "<<marks[idx][1]<<endl;
            
			    cout<<"Science: "<<marks[idx][2]<<endl;
            
			    cout<< "Second Language: "<<marks[idx][3]<<endl;
            
			    cout<<"Computer Science: "<<marks[idx][4]<<endl;
                break;

            case '2':
            	
            	setColor(5);//PURPLE COLOR
                
				cout<<"\nYour GRADE is:\t "<< calculateGrade(calculateAverage(idx))<<endl;
                break;

            case '3':
            	
                cout<<"\n*===> Your Syllabus :\n\nEnglish,\n> Math,\n> Science,\n> Second Language,\n> Computer Science\n"<<endl;
                break;

            case '4':
            	
                cout<<"\n>>> Your Attendance :\n\n Present = 90%, \n\n Absent = 10% \n"<<endl;
                break;

            case '5':
            	
                cout<<"\nEnter New Name : "<<endl;
                
                cin.ignore();
                
				getline(cin, names[idx]);
                
				saveData();
                
				cout<<"Name Updated ! \n";
                break;

            case '6':
            	
                cout<<"\nPassword Changed Successfully ! \n";
                break;

            case '7':
            	
                typingEffect("Logging Out.....", 60, 12);
                break;

            default:
                setColor(4);//FOR RED COLOR 
                
                cout<<"Invalid Choice !\n";
                
				setColor(7);//AGAIN WHITE 
        }
        system("pause");
        
    } while (choice!='7');
}

// FOR Teacher 
void createStudent() 
{
    if (studentCount>=MAX) 
	{
    		setColor(4);//LIGHT RED COLOR
    	
        cout<<"Cannot Add More Students !\n";

        setColor(7);//LIGHT WHITE COLOR
        return;
    }
    
  setColor(6);//FOR YELLOW COLOR 
  
    cout<<"\nEnter Roll Number : ";
    cin>>rollNumbers[studentCount];
  
    cin.ignore();
  
    cout<<"Enter Name : ";
    getline(cin, names[studentCount]);
  
    cout<<"Enter Marks (English, Math, Science, Language, Computer Science ):\n";
    
    for(int i=0;i<5;i++) 
	{
        cin>>marks[studentCount][i];
    }
    
	loadingAnimation("Saving Data. . .", 11);
    
    studentCount++;
    
    saveData();
    
    setColor(2);//FOR GREEN COLOR 
    
    cout<<"Student Added Successfully ! \n";
    
    setColor(7);//AGAIN WHAITE COLOR 
}

void viewAllStudents()
 {
	setColor(1);//BLUE color
    
	cout<<"\n#*>>>======> ALL STUDENTS <======<<<*#\n"<<endl;
    
	for(int i=0; i<studentCount;i++)
	 {
        cout<<"\nRoll: "<<rollNumbers[i]<<" | Name: "<<names[i]<<endl;
    
	    for (int j=0;j<5;j++) 
		{
            cout<<"Mark "<<j+1<<": "<<marks[i][j]<<endl;
        }
        
		cout<<"Average: " <<calculateAverage(i)
             <<" | Grade: "<<calculateGrade(calculateAverage(i))<<endl;
        
		cout<<"--------------------------------\n";
    }
}

void modifyStudent() 
{    
	int roll;
    
	cout<<"Enter Roll Number to Modify : ";
    
	cin>>roll;

    int idx=-1;
    
	for (int i=0;i<studentCount;i++)
	 {
        if (rollNumbers[i]==roll) 
		{
            idx=i;
            break;
        }
    }

    if (idx==-1)
	 {
	    setColor(4);// FOR  RED 
        
        cout<<"Student NOT Found !"<<endl;
        
        setColor(7);//WHITE COLOR 
        return;
    }
    
	setColor(2);//green
    
	cout<<"Enter New Name : ";
    
	setColor(7);//WHITE
    cin.ignore();
 
    getline(cin, names[idx]);
   
    setColor(5);//purple
   
    cout<<"Enter New Marks (English, Math, Science, Language, Computer Science):"<<endl;
   
   setColor(7);//WHITE
    
    for(int i=0;i<5;i++)
	 {
    	 cin>>marks[idx][i];
    }
    loadingAnimation("Updating Record. . . ", 10);
    saveData();
    
    setColor(2);//GREEN COLOR 
    
    cout<<"Record Updated ! \n";
    
    setColor(7);//AGAIN WHITE COLOR 
}

void deleteStudent() 
{
    int roll;
   
   setColor(1);//red
    
	cout<<"Enter Roll Number to Delete : ";
    cin>>roll;
    
setColor(7);//WHITE
    
	int idx=-1;
    for (int i=0;i<studentCount;i++)
	 {
        if (rollNumbers[i]==roll)
		 {
            idx=i;
            break;
        }
    }

    if (idx==-1)
	 {
        setColor(4);//RED
        
        cout<<"Student NOT found !\n";
        
		setColor(7);//WHITE 
        return;
    }

    for (int i=idx;i<studentCount - 1;i++) 
	{
        rollNumbers[i]=rollNumbers[i + 1];
    
	    names[i]=names[i + 1];
    
	    for(int j=0;j<5;j++) 
		{
            marks[i][j]=marks[i + 1][j];
        }
    }
    studentCount--;
    
	setColor(1);//WHITE
	
	loadingAnimation("Deleting Record. . .", 12);
    
	setColor(7);//WHITE
	
	saveData();
    
	setColor(1);//GREEN COLOR 
	
    cout<<"Student Deleted ! \n";
    
	setColor(7);//WHITE 
    
}

//Main Function
int main()
{
    int role;
 
    string user, pass;

    loadData();

    system("cls");
    
    typingEffect("###<*>===============================<*>###", 30, 11);
 
    typingEffect(" #                                       # ", 60, 14);

	typingEffect("  #<*>>>   WELCOME TO OUR ACADEMY  <<<*># ", 60, 14);
    
    typingEffect(" #                                       # ", 60, 14);

	typingEffect("###<*>===============================<*>###", 30, 11);
    
	loadingAnimation("\nPlease wait.....", 13);
	
    system("pause");

cout<<"\n"<<endl;

	setColor(5);//PURPLE COLOR 

	cout<<"Who are You ?\n";

	setColor(6);//FOR yellow COLOR 

cout<<"\n"<<endl;

    cout<<"1. Student\n";

cout<<"\n"<<endl;

    cout<<"2. Teacher (Admin)\n";

	setColor(7);//WHITE 

cout<<"\n"<<endl;

    cout<<"Enter Choice: ";
    cin>>role;

cout<<"\n"<<endl;

    system("cls");
    setColor(1);//blue  
    cout<<"#<**********************************>#\n"<<endl;
    
	cout<<"#<***>>>     LOGIN PAGE       <<<***>#\n"<<endl;
      	
	cout<<"#<**********************************>#\n"<<endl;
	
setColor(7);//WHITE 
	
	cout<<"UserName: \n";
    cin>>user;
    
	cout<<"Password: "<<endl;
    cin>>pass;

setColor(7);//WHITE 

    system("cls");
    
    if (role == 1)
	 {
        int roll;
        
    setColor(5);//PURPLE
	    
		cout<<"Enter Your ROLL NUMBER to Continue: ";
        cin>>roll;
        
        setColor(7);//WHITE 
        
		studentMenu(roll);
    } else {
        char ch;
    
	    system("cls");
    
	    typingEffect("\nWELCOME !!!, " + user + " (Admin)", 50, 10);
        do {
            system("cls");
    
	        loadingAnimation("\nOpening Admin Panel", 11);
    
	setColor(6);//yellow

cout<<"\n"<<endl;  
            
			cout<<"#********************************************#\n"<<endl;
setColor(1);//Blue
	        cout<<" #====>>> ACADEMY MANAGEMENT SYSTEM <<<=====#\n"<<endl;
            setColor(6);  
            cout<<"#********************************************#\n"<<endl;
setColor(7);//WHITE    
            
			cout<<"1. Add New Student\n"<<endl;
            
			cout<<"2. View All Students\n"<<endl;
            
			cout<<"3. Modify Student\n"<<endl;
            
			cout<<"4. Delete Student\n"<<endl;
            
			setColor(4);//RED 
			
			cout<<"5. Exit\n"<<endl;
            
			setColor(2);//GREEN 
			
			cout<<"Enter Your Choice: "<<endl;
            cin>>ch;
            
setColor(7);//WHITE    
            
			switch (ch) 
			{
                case '1': createStudent(); break;
            
			    case '2': viewAllStudents(); break;
            
			    case '3': modifyStudent(); break;
            
			    case '4': deleteStudent(); break;
            
			    case '5':typingEffect("Exiting System...", 60, 12); break;
            
			    default:
                	
                    setColor(4);//red
                    
                    cout << "Invalid Choice !\n";
                    
					setColor(7);//white
            }
			system("pause");
        } while (ch != '5');
    }
    return 0;
}

